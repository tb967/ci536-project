//-----------> Runs setup when page loads<------------------
window.addEventListener("load", setupPage);

function setupPage() {
    setupSearch();   //initializes search functionality
    setupDarkMode(); //initializes dark mode functionality
}

//----------->Sets up Search functionality <------------------
function setupSearch() {
    const searchForm = document.getElementById("search-form");
    const searchInput = document.getElementById("search-input");

    //listen for the form submission
    searchForm.addEventListener("submit", function (event) {
        event.preventDefault();
        const query = searchInput.value.trim();
        if (query) {
            fetchImages(query);
        } else {
            displayMessage("Please enter a search term.");
        }
    });
}


//----------> Fetchs images from NASA API <---------------------------
function fetchImages(query) {
    const apiUrl = `https://images-api.nasa.gov/search?q=${encodeURIComponent(query)}&media_type=image`;

    //show loading spinner before making the API request
    showLoading();

    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            return response.json();
        })
        .then(data => {
            displayResults(data.collection.items, query);
        })
        .catch(() => {
            displayMessage("Error loading images. Try again later.");
        });
}

//-------------->Displays results dynamically <---------------------------
function displayResults(items, query) {
    const resultsContainer = document.getElementById("results");
    const searchMessageContainer = document.getElementById("search-message");

    //set the search message
    searchMessageContainer.textContent = `Results for ${query}`;

    //remove loading spinner
    hideLoading();

    //remove all previous results
    while (resultsContainer.firstChild) {
        resultsContainer.removeChild(resultsContainer.firstChild);
    }

    if (items.length === 0) {
        displayMessage("No images found. Try a different search term.");
        return;
    }

    items.forEach(item => {
        if (!item.links || !item.data) return; //skips invalid entries

        const imageUrl = item.links[0].href;
        const title = item.data[0].title || "No Title";
        const description = item.data[0].description || "No Description Available";
        const date = item.data[0].date_created ? new Date(item.data[0].date_created).toDateString() : "Unknown Date";

        //creates result container 
        const resultItem = document.createElement("div");
        resultItem.classList.add("result-item");

        //image element
        const img = document.createElement("img");
        img.src = imageUrl;
        img.alt = title;
        img.loading = "lazy";

        //title element
        const titleElement = document.createElement("h3");
        titleElement.textContent = title;

        //description element
        const descriptionElement = document.createElement("p");
        descriptionElement.textContent = description.substring(0, 300) + "...";

        //date element
        const dateElement = document.createElement("p");
        const strong = document.createElement("strong");
        strong.textContent = "Date: "; 
        dateElement.appendChild(strong);
        dateElement.appendChild(document.createTextNode(date));

        //appends elements properly
        resultItem.appendChild(img);
        resultItem.appendChild(titleElement);
        resultItem.appendChild(descriptionElement);
        resultItem.appendChild(dateElement);
        resultsContainer.appendChild(resultItem);
    });

    // show "Go to Top" button
    const goToTopButton = document.getElementById("go-to-top");
    goToTopButton.style.display = "block";

    //event listener for "Go to Top" button click
    goToTopButton.addEventListener("click", function () {
        document.getElementById("top").scrollIntoView({ behavior: "smooth" });
    });
    
    //scroll to results after displaying
    scrollToResults();

}

//------------> Function to display messages in results area <--------------
function displayMessage(message) {
    const resultsContainer = document.getElementById("results");

    //removes all previous results/messages
    while (resultsContainer.firstChild) {
        resultsContainer.removeChild(resultsContainer.firstChild);
    }

    const messageElement = document.createElement("p");
    messageElement.textContent = message;
    resultsContainer.appendChild(messageElement);

    //scroll to results when showing message
    scrollToResults();

}

//show loading spinner
function showLoading() {
    const spinner = document.getElementById("loading-spinner");
    spinner.style.display = "block";
}

//hide loading spinner
function hideLoading() {
    const spinner = document.getElementById("loading-spinner");
    spinner.style.display = "none";
}

//----------->Scrolls smoothly to results section <------------------
function scrollToResults() {
    const resultsContainer = document.getElementById("search-message");
    resultsContainer.scrollIntoView({ behavior: "smooth" });
}

//----------->Sets up Dark Mode toggle <------------------
function setupDarkMode() {
    const themeToggle = document.getElementById("toggle-theme");

    if (!themeToggle) return; //ensures button exists before proceeding

    //load dark mode preference from local storage
    if (localStorage.getItem("dark-mode") === "enabled") {
        enableDarkMode();
    }

    //toggle dark mode on button click
    themeToggle.addEventListener("click", function () {
        if (document.body.classList.contains("dark-mode")) {
            disableDarkMode();
        } else {
            enableDarkMode();
        }
    });
}

//----------->Enables Dark Mode <------------------
function enableDarkMode() {
    document.body.classList.add("dark-mode");
    localStorage.setItem("dark-mode", "enabled");

    //update button text to match theme
    updateThemeButton();
}

//----------->Disables Dark Mode <------------------
function disableDarkMode() {
    document.body.classList.remove("dark-mode");
    localStorage.setItem("dark-mode", "disabled");

    //update button text to match theme
    updateThemeButton();
}

//----------->Updates theme toggle button text <------------------
function updateThemeButton() {
    const themeToggle = document.getElementById("toggle-theme");
    if (!themeToggle) return;

    if (document.body.classList.contains("dark-mode")) {
        themeToggle.textContent = "Day Mode 🌞";
    } else {
        themeToggle.textContent = "Night Mode 🌚";
    }
}
